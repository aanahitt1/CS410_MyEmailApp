package com.example.myemailapp;

import android.os.StrictMode;

import java.util.Properties;

import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

public class Connection {

    private static Connection instance;
    private Store store;


    public void establishConnection(String username, String password) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Properties props = System.getProperties();
        props.setProperty("mail.store.protocol", "imaps");
        Session session = Session.getDefaultInstance(props);

        try {
            store = session.getStore("imaps");
            store.connect("imap.gmail.com", username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getInstance() {
        if (instance == null) {
            instance = new Connection();
            return instance;
        } else {
            return instance;
        }
    }

    public Folder getFolder(String folderName) throws MessagingException {
        if (folderName != null && store != null) {
            return store.getFolder(folderName);
        }
        throw(new MessagingException("forlderName or store is null!"));
    }

}