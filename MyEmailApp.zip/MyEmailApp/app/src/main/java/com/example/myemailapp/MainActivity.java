package com.example.myemailapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MainActivity extends AppCompatActivity {
    private static final String REPLY_HEADER = "\n\n\n ------------------------------------------------------------\n";
    private EditText eTo;
    private EditText eSubject;
    private EditText eMsg;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eTo = (EditText)findViewById(R.id.txtTo);
        eSubject = (EditText)findViewById(R.id.txtSub);
        eMsg = (EditText)findViewById(R.id.txtMsg);
        btn = (Button)findViewById(R.id.btnSend);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //This creates the message by setting all the fields necessary for the message.
                    MimeMessage message = new MimeMessage(getSession());
                    message.setContent(eMsg.getText().toString(), "text/html");
                    message.setSubject(eSubject.getText().toString());
                    message.addRecipient(Message.RecipientType.TO, new InternetAddress(eTo.getText().toString()));
                    message.setSentDate(new Date());

                    //We send using Java.mail
                    Transport.send(message);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
        });

        String error = "Message not loading";
        String messageSubject;

        Bundle bundle = getIntent().getExtras();

        try {
            if(bundle != null) {
                String isReplyEmailStr = bundle.getString("isReplyEmail", "false");
                boolean isReplyEmail = Boolean.parseBoolean(isReplyEmailStr);
                if(isReplyEmail) {
                    messageSubject = bundle.getString("subject", "missing subject!");
                    eSubject.setText(messageSubject);
                    eTo.setText(bundle.getString("sender", "missing sender!"));
                    String replyBody = REPLY_HEADER + bundle.getString("content", "missing content");
                    eMsg.setText(replyBody);
                }
            }
        } catch (Exception e) {
            eMsg.setText(error);
        }
    }

    //This method returns an SMTP connection session that can be used to send the email.
    public Session getSession() {
        Properties prop = System.getProperties();
        prop.setProperty("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(prop, Connection.getAuth());
        return session;
    }
}

