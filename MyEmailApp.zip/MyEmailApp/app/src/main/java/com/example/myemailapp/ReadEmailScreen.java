package com.example.myemailapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReadEmailScreen extends AppCompatActivity {

    public ReadEmailScreen() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_email_screen);
        boolean isReplyEmail = false;

        //make a clickable reply button
        ImageButton replyButton = findViewById(R.id.replyButton);
        replyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //go to MainActivity after clicking a compose button
                Intent myIntent = new Intent(ReadEmailScreen.this, MainActivity.class);
                Bundle bundle = getIntent().getExtras();
                bundle.putString("isReplyEmail", "true");
                myIntent.putExtras(bundle);
                startActivity(myIntent);
            }
        });

        TextView content = findViewById(R.id.filling);
        TextView subject = findViewById(R.id.subject);
        TextView address = findViewById(R.id.sender);
        subject.setY(0);
        address.setY(35);
        content.setY(65);
        String error = "Message not loading";
        String messageSubject;

        Bundle bundle = getIntent().getExtras();
        try {
            if(bundle != null) {
                messageSubject = bundle.getString("subject", "missing subject!");
                subject.setText(messageSubject);
                address.setText(bundle.getString("sender", "missing sender!"));
                content.setText(bundle.getString("content","missing content"));
            } else {
                messageSubject = "Bundle is null";
                subject.setText(messageSubject);
            }
        } catch (Exception e) {
            content.setText(error);
        }
    }
}

